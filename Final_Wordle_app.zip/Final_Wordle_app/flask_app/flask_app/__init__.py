from flask import *
from random_five_letter_word import scrape_word
app = Flask(__name__)


#route goes before function.
@app.route('/page_two')
def page_two():
    return render_template('page_two.html', name = "Kenean")

@app.route('/')
@app.route('/index')
def index():
    return render_template('index.html', name = "Kenean")

@app.route('/page_form')
def page_form():
    return render_template('page_form.html', name = "Kenean")

def page_form():
    return render_template('page_form.html', name = "Kenean")

import re 
import os
import random
from bs4 import BeautifulSoup
from colorama import Fore
import requests

def is_word_in_mw(word):
    url = f"https://www.merriam-webster.com/dictionary/{word}"
    response = requests.get(url)
    soup = BeautifulSoup(response.text, "html.parser")
    # Check if the page contains a definition
    if soup.find(class_="sense") is not None:
        return True
    return False

def pick_random_word():
    url = "https://www.coolgenerator.com/5-letter-word-generator"
    word = scrape_word(url) 
    print(word)
    return word.lower()

class wordleboard:
    def __init__(self):
        self.board = [['_', '_', '_', '_', '_'],
                      ['_', '_', '_', '_', '_'],
                      ['_', '_', '_', '_', '_'],
                      ['_', '_', '_', '_', '_'],
                      ['_', '_', '_', '_', '_'],
                      ['_', '_', '_', '_', '_']]
        self.current_row = 0
    
    def __repr__(self):
        return self.draw_box()

    def draw_box(self):
        box_top = "<pre style='font-size:50px;margin:0;padding:0'>┌─────┐\n"
        box_bottom = "└─────┘</pre>\n"
        box_middle = "│"

        board_str = box_top
        for row in self.board:
            row_str = ''
            for letter in row:
                row_str += f'<span style="color:{self.get_color(letter)};font-size:50px">{letter}</span>'
            board_str += f"<pre style='font-size:50px;margin:0;padding:0'>{box_middle}{row_str}{box_middle}\n</pre>"
        board_str += box_bottom

        return board_str

    def get_color(self, letter):
        if letter == '_':
            return 'black'
        elif letter in aslist:
            return 'yellow'
        else:
            return 'green'

    def updatewb(self, word):
        newword = list(word)
        # Make analysis
        for index, letter in enumerate(newword):
            if aslist[index] == letter:
                newword[index] = f'<span style="color:green;font-size:50px">{letter}</span>'
            elif letter in aslist:
                newword[index] = f'<span style="color:goldenrod;font-size:50px">{letter}</span>'
            else:
                newword[index] = f'<span style="color:gray;font-size:50px">{letter}</span>'
        
        self.board[self.current_row] = newword
        self.current_row += 1  # Move to the next row for the next guess
   
myboard = wordleboard()

# Route for the game page
@app.route('/wordle')
def wordle():
    global gameword, aslist, myboard
    gameword = pick_random_word().strip().lower()
    aslist = list(gameword)
    myboard = wordleboard()  # Create a new board for each game
    return render_template('wordle.html', gameword=gameword, aslist=aslist, myboard=myboard)


# Route for submitting guesses
@app.route('/guess', methods=['POST'])
def make_guess():
    guessword = request.form['guess'].lower() 
    if guessword == gameword:
        return "Congratulations! You've won!"
    elif not is_word_in_mw(guessword.lower()):
        return "Your guess is not a valid English word." + render_template('wordle.html', gameword=gameword, aslist=aslist, myboard=myboard)
    else:
        # Process the guess and update the board
        myboard.updatewb(guessword.lower())
        return render_template('wordle.html', gameword=gameword, aslist=aslist, myboard=myboard)




    

if __name__=='__main__':
    
    app.run(debug=True)