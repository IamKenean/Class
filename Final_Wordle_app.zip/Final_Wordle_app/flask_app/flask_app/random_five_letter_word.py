import requests
from bs4 import BeautifulSoup

def scrape_word(url):
    try:
        # Fetch the HTML content
        response = requests.get(url)
        response.raise_for_status()  # Raise an exception for any HTTP errors

        # Parse the HTML using BeautifulSoup
        soup = BeautifulSoup(response.content, "html.parser")

        # Find the <p> tag with the specified class
        word_tag = soup.find("p", class_="text-center font-18")

        # Extract the text inside the <span> tag within the <p> tag
        if word_tag:
            word_span = word_tag.find("span")
            if word_span:
                return word_span.text.strip()
            else:
                return "Word not found within <span> tag."
        else:
            return "Word paragraph not found on the webpage."

    except requests.RequestException as e:
        return f"Error fetching webpage: {e}"

# Test the function
url = "https://www.coolgenerator.com/5-letter-word-generator"
word = scrape_word(url)

