from flask import *
app = Flask(__name__)
import os

@app.route('/')
@app.route('/index')
@app.route('/page_two')

def page_two():
    return render_template('page_two.html', name = "Kenean")
def index():
    return render_template('index.html', name = "Kenean")
if __name__=='__main__':
    app.run(debug=True)